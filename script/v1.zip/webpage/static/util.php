<?php


$config = json_decode(file_get_contents('theme.json'), true);
$bgColor = $config['background'];
$fgColor = $config['text'];

function checkPort($host, $port, $timeout = 3) {
    $fp = @fsockopen($host, $port, $errno, $errstr, $timeout);
    if ($fp) {
        fclose($fp);
        return true;
    }
    return false;
};
function pageLink($host,$port,$pagePath = "") {
    if (!empty($pagePath)) {
        echo "http://{$host}:{$port}/{$pagePath}";
        return "http://{$host}:{$port}/{$pagePath}";
    } else {
        echo "http://{$host}:{$port}";
        return "http://{$host}:{$port}";
    }
};
?>