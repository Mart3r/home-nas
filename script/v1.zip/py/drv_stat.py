from collections import namedtuple
import subprocess,yaml,os.path,datetime

drv_yaml = "/server/drives.yml"
    
std = namedtuple("std",['stdin','stdout','stderr','return_code'],defaults=["","","",1])
drv_size = namedtuple("drive_size",['free','used','total','percent'],defaults=["0B","0B","0B",0])
def call(cmd:str) -> std: 
    'Returns Named Tuple (stdin,stdout,stderr,return_code)'
    resp=subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=True)
    return std(cmd, resp.stdout.decode().strip(), resp.stderr.decode().strip(), resp.returncode)
def findMount(uuid)->str: return call(f"findmnt -n -o TARGET -S UUID={uuid}").stdout
def uuidExist(uuid)->bool: return os.path.exists(f"/dev/disk/by-uuid/{uuid}")
def mount(uuid,path)->std: return call(f"sudo mount UUID={uuid} {path}")
def unmount(uuid)->std: return call(f"sudo umount UUID={uuid}")
    
def __convert(inp:str)->float:
    if "B" in inp: return float(inp.removesuffix("B"))
    elif "K" in inp: return float(inp.removesuffix("K")) * 1024
    elif "M" in inp: return float(inp.removesuffix("M")) * 1024 * 1024
    elif "G" in inp: return float(inp.removesuffix("G")) * 1024 * 1024 * 1024
    elif "T" in inp: return float(inp.removesuffix("T")) * 1024 * 1024 * 1024 * 1024
    else: return None

def getSize(uuid)->drv_size:
    device  = str(call(f'lsblk -o NAME,UUID | grep " {uuid}"').stdout).replace("─","").replace("└","").replace("├","").replace("\n\n","\n").replace(f" {uuid}","")
    fs_info = call(f"df -h | grep {device}").stdout
    free    = __convert(call(f'echo "{fs_info}"'+" | awk '{print $4}'").stdout)
    used    = __convert(call(f'echo "{fs_info}"'+" | awk '{print $3}'").stdout)
    total   = __convert(call(f'echo "{fs_info}"'+" | awk '{print $2}'").stdout)
    percent = used/(total / 100)
    percent=f"{percent:.2f}"
    return drv_size(free,used,total,percent)

def driveSize(uuid)->str:
    sz = getSize(uuid)
    used,total = "{:.2f}".format(sz.used/1024/1024/1024) , "{:.2f}".format(sz.total/1024/1024/1024)
    return f'{used}/{total}GB  {sz.percent}%'

def center(text:str,max_length:int):
    l=len(text)
    s=(max_length-l) / 2
    if "." in str(s): 
        z = int(str(s).split(".",1)[0])
        prefix, suffix = z, z+1
    else: prefix=suffix=s
    return f"{' '*prefix}{text}{' '*suffix}"

if os.path.exists(drv_yaml): drv_conf:dict = yaml.safe_load(open(drv_yaml))
else: 
    print(f'Config File Not Found "{drv_yaml}"')
    exit(1)

print(f'\033[0mConfig File: "\033[0;36m{drv_yaml}\033[0m"')
for label, data in drv_conf.items():
    enabled, uuid, path, script = data.get("ENABLE",False), data.get("UUID",None), data.get("PATH",None), data.get("SCRIPT",None)
    if enabled:
        if (uuid is not None) or (path is not None):
            if uuidExist(uuid):
                current_mount = findMount(uuid)
                if current_mount.strip() == "": CLR,STATUS = "\033[0;33m", "UNMOUNTED"
                elif current_mount == path: CLR,STATUS = "\033[0;32m", "MOUNTED"
                elif current_mount != path: CLR,STATUS = "\033[0;33m", "WRONG PATH"
                else: CLR,STATUS = "\033[0;31m", "UNKNOW"
            else: CLR,STATUS = "\033[0;31m", "NOT FOUND"
            SCR = f'Script: \033[0;36m"{script}"\033[0m' if script != None else 'Script: \033[0;31mNone\033[0m'
            try: SIZE = driveSize(uuid) if (CLR != "\033[0;31m") else ""
            except: SIZE = "Unknow"
            print(f'{CLR}[#]  {center(STATUS,10)}\033[0m   Display Name: \033[0;36m"{label}"\033[0m  UUID: \033[0;36m"{uuid}"\033[0m  Size: {SIZE}  {SCR} \033[0m')      
exit(0)