
ROOT_FOLDER="/nas/container/airsonic"

sudo mkdir -p $ROOT_FOLDER
docker run \
  -v data:$ROOT_FOLDER/data \
  -v music:$ROOT_FOLDER/music \
  -v playlists:$ROOT_FOLDER/playlists \
  -v podcasts:$ROOT_FOLDER/podcasts \
  -p 4040:4040 \
  -d \
  airsonic/airsonic

ufw allow 4040