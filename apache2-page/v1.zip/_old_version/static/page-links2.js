window.onload = function() {
    var host = window.location.hostname;
    services.forEach(service => {
        setLink(service.id,service.port)
        setAutoLink(`${service.id}-auto`,service.port)
    });

    function setLink(elementId, port) {
        let el = document.getElementById(elementId);
        if (el) el.href = `http://${host}:${port}/`;
    }
    function setAutoLink(elementId, port) {
        let el = document.getElementById(elementId);
        if (el) window.location.href = `http://${host}:${port}/`;
    }
    function setPageLink(elementId, pagePath) {
        let el = document.getElementById(elementId);
        if (el) el.href = `http://${host}/${pagePath}`;
    }
};
