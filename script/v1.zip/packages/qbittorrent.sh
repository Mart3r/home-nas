
ROOT_FOLDER="/nas/container/qbittorrent"

sudo mkdir -p $ROOT_FOLDER
docker run -d --name=qbittorrent \
    -p 8081:8081 -p 8082:6881 -p 8082:6881/udp \
    -e WEBUI_PORT=8081 \
    -v $ROOT_FOLDER/config:/config \
    -v $ROOT_FOLDER/downloads:/downloads \
    linuxserver/qbittorrent

ufw allow 8081