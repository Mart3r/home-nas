
set_if_empty() {local var_name="$1";local default_value="$2";if [ -z "${!var_name}" ];then;declare -g "$var_name=$default_value";fi;echo "${!var_name}";}


sudo mkdir /tmp/ssl_gen

echo "Output Path (cert.crt, private.pem)[$HOME]: ";read path
echo "Certificate Duration (Days)[365]: ";read duration
echo "Certificate Info >> "
echo "Common Name [Empty]: "; read _CN
echo "<Location> Country Code [CZ]: "; read _C
echo "<Location> State/Province [Czech Republic]: "; read _S
echo "<Location> Locality [Praha]: ";read _L
echo "<Organization> Name [Empty]: ";read _O
echo "<Organization> Unit [Empty]: ";read _OU

_C= set_if_empty $_C "CZ"
_S= set_if_empty $_S "Czech Republic"
_L= set_if_empty $_L "Praha"

adt_opts=""
path= set_if_empty $path $HOME
duration= set_if_empty $duration "365"

priv_key="/tmp/ssl_gen/priv.key"
csr="/tmp/ssl_gen/csr.pem"
crt="$path/cert.crt"
opts="/CN=Test/OU=Personal/L=Praha/S=Czech Republic/O=Personal/C=CZ$adt_opts"
_algorithm="RSA"

sudo openssl genpkey -algorithm $_algorithm -out $priv_key
sudo openssl req -new -key $priv_key -out $csr -subj $opts
sudo openssl x509 -req -days $duration -in $csr -signkey $priv_key -out $crt

sudo cp "/tmp/ssl_gen/priv.key" "$path/private.pem"