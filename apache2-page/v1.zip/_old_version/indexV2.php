<?php
include_once 'static/check_port.php';
$services = json_decode(file_get_contents('services.json'), true);
?>

<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="static/styles.css">
    <title>My Server Services</title>
    <script src="static/page-links.js"></script>
</head>
<body style="background-color:rgb(25,25,25); color: rgb(238, 238, 238)">
    <h1>Welcome to My Server Services</h1>
    <ul>
        <li><a id="downloads-link" href="#"><button class="button-28" role="button" type="button" style="width: 150px;">Downloads</button></a></li>
<?php foreach ($services as $service) {
    if (checkPort('localhost', $service['port'])) { echo "<li><a id=\"{$service['id']}\" href=\"#\"><button class=\"button-28\" role=\"button\" type=\"button\" style=\"width: 150px;\">{$service['name']}</button></a></li>"; }} ?>

    </ul>
</body>
</html>