#!/bin/bash

# Functions:
enable() { sudo sed -i "s/^\([#;]\)\(\s*${1}\)/\2/" "$2"; }
disable() { sudo sed -i "/^[^#;]\s*${1}\s*=/s/^/#/" "$2"; }
edit() {
    grep -qE "^[#;]?\s*${1}\b" "$3" || echo "${1} ${2}" >> "$3"
    sudo sed -i "s/^\([#;]\s*\)\?\(${1}\)\b.*/\2 ${2}/" "$3"
}
lower() { echo "$1" | awk '{print tolower($0)}'; }

cwd=$(dirname $(readlink -f $0))
user=${SUDO_USER:-$USER}

has_sudo_rights=$(sudo -l &>/dev/null && echo true || echo false)
if $has_sudo_rights; then echo "Sudo OK"; else echo "User dont have Sudo Rights"; exit 1; fi;

sudo bash "$cwd/docker.sh"
sudo bash "$cwd/portainer.sh"

sudo bash "$cwd/jellyfin.sh"
sudo bash "$cwd/photoprism.sh"