<?php
include_once 'static/util.php';
$host = $_SERVER['SERVER_NAME'];
$services = json_decode(file_get_contents('services.json'), true);
?>

<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="static/styles.css">
    <title>My Server Services</title>
    <script src="static/page-links.js"></script>
</head>
<body style="background-color:<?= $bgColor ?>; color: <?= $fgColor ?>">
    <h1>Welcome to My Server Services</h1>
    <ul>
        <li><a href="<?php pageLink($host,'80','download.php')?>"><button class="button-28" role="button" type="button" style="width: 150px;">Downloads</button></a></li>
<?php 
    foreach ($services as $service) {
    if (checkPort('localhost', $service['port'])) { echo "<li><a href=\"http://{$host}:{$service['port']}\"><button class=\"button-28\" role=\"button\" type=\"button\" style=\"width: 150px;\">{$service['name']}</button></a></li>"; }} ?>

    </ul>
</body>
</html>