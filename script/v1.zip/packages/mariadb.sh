#!/bin/bash
cwd=$(dirname $(readlink -f $0))

sudo apt install mariadb-server -y
sudo apt-get install expect -y
MYSQL_ROOT=$1

echo "MariaDB Installed ...";echo "Trying to setup SQL Secure Installation"
#echo "New MySQL Root Password"; read MYSQL_ROOT
export MYSQL_ROOT_PASSWORD=$MYSQL_ROOT
sudo sh $cwd/_mysql_expect.sh
unset MYSQL_ROOT_PASSWORD