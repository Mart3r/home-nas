<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="static/styles.css">
    <title>My Server Services</title>
    <script src="static/page-links.js"></script>
</head>
<body style="background-color:rgb(25,25,25); color: rgb(238, 238, 238)">
    <h1>Welcome to My Server Services</h1>
    <ul>
        <li><a id="indexV2-link" href="#"><button class="button-28" role="button" type="button" style="width: 150px;">Version 2</button></a></li>
        <?php include_once 'static/check_port.php'; $port = 10000; if (checkPort('localhost', $port)): ?><li><a id="webmin-link" href="#"><button class="button-28" role="button" type="button" style="width: 150px;">Webmin</button></a></li><?php endif; ?>
        <?php include_once 'static/check_port.php'; $port = 9000; if (checkPort('localhost', $port)): ?><li><a id="portainer-link" href="#"><button class="button-28" role="button" type="button" style="width: 150px;">Portainer</button></a></li><?php endif; ?>
        <?php include_once 'static/check_port.php'; $port = 8200; if (checkPort('localhost', $port)): ?><li><a id="dlna-link" href="#"><button class="button-28" role="button" type="button" style="width: 150px;">DLNA</button></a></li><?php endif; ?>
        <?php include_once 'static/check_port.php'; $port = 8080; if (checkPort('localhost', $port)): ?><li><a id="nextcloud-link" href="#"><button class="button-28" role="button" type="button" style="width: 150px;">Nextcloud</button></a></li><?php endif; ?>
        <!-- Add more list items as needed, and make sure to give them unique id attributes. -->
    </ul>
</body>
</html>