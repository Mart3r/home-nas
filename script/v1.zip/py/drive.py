from collections import namedtuple
from shlex import split
import os.path,subprocess,yaml,json

global drv_conf,usr_conf,service_conf

drv_conf:dict = {}
std = namedtuple("std",['stdin','stdout','stderr','return_code'],defaults=["","","",1])
drive = namedtuple("drive",["uuid_found","label","uuid","current_path","mount_path","script"])

def call(cmd:str) -> std: 
    'Returns Named Tuple (stdin,stdout,stderr,return_code)'
    resp=subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=True)
    #if resp.returncode!=0:print(f'[call] "{cmd}"   Error: {resp.stderr}')
    return std(cmd, resp.stdout.decode().strip(), resp.stderr.decode().strip(), resp.returncode)
def findMount(uuid)->str: return call(f"findmnt -n -o TARGET -S UUID={uuid}").stdout
def uuidExist(uuid)->bool: return os.path.exists(f"/dev/disk/by-uuid/{uuid}")
def mount(uuid,path)->std: return call(f"sudo mount UUID={uuid} {path}")
def unmount(uuid)->std: return call(f"sudo umount UUID={uuid}")
def center(text:str,max_length:int):
    l=len(text)
    s=(max_length-l) / 2
    if "." in str(s): 
        z = int(str(s).split(".",1)[0])
        prefix, suffix = z, z+1
    else: prefix=suffix=s
    return f"{' '*prefix}{text}{' '*suffix}"
def list_drives()->list[drive]:
    drvs = []
    for label, data in drv_conf.items():
        enabled, uuid, path, script = data.get("ENABLE",False), data.get("UUID",None), data.get("PATH",None), data.get("SCRIPT",None)
        if enabled:
            if (uuid is not None) or (path is not None):
                if uuidExist(uuid):
                    current=findMount(uuid)
                    found=True
                else: found,current = False, ""
                drvs.append(drive(found,label,uuid,current,path,script))
    return drvs

ALLOW_SCRIPT = False
CREATE_PATH = False

def mountByLabel(label):
    drives = list_drives()
    for drv in drives:
        if label==drv.label and drv.uuid_found:
            if os.path.exists(drv.mount_path)==False:
                if CREATE_PATH: call(f"sudo mkdir -p {drv.mount_path}")
                else: print("Mount Path Dont Exist")
            if str(drv.current_path).strip()!="": unmount(drv.uuid)
            mount(drv.uuid,drv.mount_path)
def unmountByLabel(label):
    drives = list_drives()
    for drv in drives:
        if label==drv.label and drv.uuid_found: 
            unmount(drv.uuid)       
def auto_remount():
    drives = list_drives()
    for drv in drives:
        if drv.uuid_found:
            if os.path.exists(drv.mount_path)==False:
                if CREATE_PATH: call(f"sudo mkdir -p {drv.mount_path}")
                else: print("Mount Path Dont Exist")
            if drv.current_path != drv.mount_path:
                if str(drv.current_path).strip()!="": unmount(drv.uuid)
                mount(drv.uuid,drv.mount_path)
                if (drv.script != None) and ALLOW_SCRIPT: call(f"sudo bash {drv.script}")
def drive_status():
    drives = list_drives()
    for drv in drives: 
        if drv.uuid_found: 
            if drv.current_path.strip() == "": CLR,STATUS = "\033[0;33m", "UNMOUNTED"
            elif drv.current_path == drv.mount_path: CLR,STATUS = "\033[0;32m", "MOUNTED"
            elif drv.current_path != drv.mount_path: CLR,STATUS = "\033[0;33m", "WRONG PATH"
            else: CLR,STATUS = "\033[0;31m", "UNKNOW"
        else: CLR,STATUS = "\033[0;31m", "NOT FOUND"
        SCR = f'Script: \033[0;36m"{drv.script}"\033[0m' if drv.script != None else 'Script: \033[0;31mNone\033[0m'
        print(f'{CLR}[#]  {center(STATUS,10)}\033[0m   Display Name: \033[0;36m"{drv.label}"\033[0m  UUID: \033[0;36m"{drv.uuid}"\033[0m  {SCR} \033[0m') 

# Users
def list_users():
    users = str(call("awk -F: '$3 >= 1000 && $3 < 65534 {print $1}' /etc/passwd").stdout).split("\n")
    return users
def adduser(username:None,password:None):
    if (username==None) or (password==None):print("Args: <username> <password>")
    else:
        home = usr_conf["USERS"].get('HOME',"/home")
        member = usr_conf["GROUPS"].get('MEMBER','smember')
        call(f'sudo useradd -m -s /bin/bash -b {home} "{username}"')
        call(f'echo "{username}:{password}" | sudo chpasswd')
        call(f'sudo usermod -a -G {member} {username}')
        call(f'sudo chown -R {username}:{username} "{home}/{username}"; sudo chmod -R 0770 "{home}/{username}"')
def deluser(username:None): 
    if username==None:print("Args: <username>")
    else: call(f'sudo deluser {username}')

# Services
def add_service(name:None,port:None,id:None): 
    if (name==None) or (port==None): print("Args: <name> <port>")
    else: service_conf.append({'port':port,'id':id,'name':name})
def rm_service(name:None):
    if name==None:print("Args: <name>")
    else:
        for service in service_conf:
            if service['name']==name: service_conf.remove({'port':service['port'],'id':service['id'],'name':name})
def list_service():
    for service in service_conf:
        name,port,id = service['name'], service['port'], service['id']
        print(f'Name: "{name}"  Port: {port}  ID: "{id}"')
def save_service(): 
    global service_conf
    json.dump(service_conf,open(service_json,'w'))
    service_conf = json.load(open(service_json,"r"))

prefix=""
exit_comm=['end','exit']

drv_yaml = "/nas/conf/drives.yml"
usr_yaml = "/nas/conf/users.yml"
service_json = "/var/www/html/services.json"

if os.path.exists(drv_yaml): drv_conf, _DRIVE = yaml.safe_load(open(drv_yaml)), True
else: _DRIVE = False

if os.path.exists(usr_yaml): usr_conf, _USER = yaml.safe_load(open(usr_yaml)), True
else: _USER = False

if os.path.exists(service_json): service_conf, _SERVICE = json.load(open(service_json,"r")), True
else: _SERVICE = False  

print(f'[CLI] Exit Commands: {", ".join(exit_comm)}')
while True:
    try:
        args=split(input(f"[{prefix}]> "))
        for i in range(6):args.append(None)
        if args[0] in exit_comm:exit(0)
        #elif args[0]=="set": globals().update({args[1]:args[2]})
        #elif args[0]=="unset": globals().pop(args[1])
        elif args[0]=="prefix": prefix=args[1]
        elif args[0]=="drive":
            if _DRIVE:
                drvs = list_drives()
                if args[1]=="auto":auto_remount()
                elif args[1]=="list":
                    for drv in list_drives():print(f'Label: "{drv.label}"  UUID: "{drv.uuid}"  {"Found" if drv.uuid_found else "Not Found"}')
                elif args[1]=="status":drive_status()
                elif args[1]=="mount":mountByLabel(args[2])
                elif args[1]=="unmount":unmountByLabel(args[2])
            else: print(f"Drive Config Not Found: {drv_yaml}")
        elif args[0]=="user":
            if _USER:
                if args[1]=="add":adduser(args[2],args[3])
                elif args[1]=="del":
                    if input(f"Are you sure to delete user {args[2]} ? (y/n)> ").lower()=="y": deluser(args[2])
                elif args[1]=="list": print(f"Users: {', '.join(list_users())}")
            else: print(f"User Config Not Found: {usr_yaml}")
        elif args[0]=="service":
            if _SERVICE:
                if args[1]=="add": add_service(args[2],args[3],f'{str(args[2]).lower()}-link')
                elif args[1]=="del": rm_service(args[2])
                elif args[1]=="list": list_service()
                elif args[1]=="save": save_service()
    except Exception as e:print(e)