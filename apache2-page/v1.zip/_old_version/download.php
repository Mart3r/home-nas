<?php $downloadDir = 'downloads';  $files = array_diff(scandir($downloadDir), array('.', '..')); ?>

<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="static/styles.css">
    <title>Downloads</title>
    <script src="static/page-links.js"></script>
</head>
<body style="background-color:rgb(25,25,25); color: rgb(238, 238, 238)">
    <h1>Available Downloads</h1>
    <ul>
        <?php foreach ($files as $file): ?>
            <li><a href="<?php echo $downloadDir . '/' . $file; ?>" download><button class="button-28" role="button" type="button" style="width: 150px;"><?php echo $file; ?></button></a></li>
        <?php endforeach; ?>
    </ul>
</body>
</html>