#!/bin/bash
newhost=$1
oldhost=$(hostname)
if [ -z "$newhost" ]
then
    echo "Error NewHost Argument Missing"
    exit 2
fi
echo "Old Host $oldhost | New Host $newhost"
echo "$newhost" | sudo tee /etc/hostname
sudo sed -i "s|^127.0.1.1.*|127.0.1.1   ${newhost}|g" /etc/hosts
sudo hostnamectl set-hostname $newhost
echo "Hostname Updated. Reboot Needed."
exit 0 