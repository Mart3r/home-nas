curl -fsSL https://download.docker.com/linux/ubuntu/gpg | sudo apt-key add -
sudo add-apt-repository "deb [arch=arm7] https://download.docker.com/linux/ubuntu $(lsb_release -cs) stable"
sudo apt update
