apt install lsb-release ca-certificates apt-transport-https software-properties-common gnupg2
REPO_LINE="deb https://packages.sury.org/php/ $(lsb_release -sc) main"
REPO_FILE="/etc/apt/sources.list.d/sury-php.list"
if ! grep -q "$REPO_LINE" "$REPO_FILE"; then echo "$REPO_LINE" | sudo tee -a "$REPO_FILE" && echo "Repository added!"; else echo "Repository already exists!"; fi
wget -qO - https://packages.sury.org/php/apt.gpg | apt-key add - 
apt update -y
exit 0 