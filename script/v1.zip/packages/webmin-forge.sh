#!/bin/sh
version="2.100"
sudo apt-get install perl libnet-ssleay-perl openssl libauthen-pam-perl libpam-runtime libio-pty-perl apt-show-versions python unzip -y
sudo wget -O /tmp/webmin.deb "http://prdownloads.sourceforge.net/webadmin/webmin_{$version}_all.deb"
sudo dpkg --install "/tmp/webmin.deb"
ufw allow 10000
exit 0