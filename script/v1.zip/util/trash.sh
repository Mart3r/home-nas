sudo mv --force -t /server/trash $@
echo "Moved to Trash: $@"