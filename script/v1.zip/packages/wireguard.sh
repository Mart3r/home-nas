sudo apt update
sudo apt install wireguard

wg_profile_name="wg0"

#  Private & Public Key Pair
wg genkey | sudo tee /etc/wireguard/private.key
sudo chmod go= /etc/wireguard/private.key
sudo cat /etc/wireguard/private.key | wg pubkey | sudo tee /etc/wireguard/public.key
_prv_key=$(sudo cat /etc/wireguard/private.key)
_pub_key=$(sudo cat /etc/wireguard/public.key)

#  ipv4
_ip4="10.0.0.1"

#  ipv6
_date_value=$(date +%s%N)
_machine_id=$(cat /var/lib/dbus/machine-id)
_ip6=$(printf "$_date_value$_machine_id" | sha1sum | cut -c 1-12 | sed 's/\(....\)/\1:/g' | sed 's/:$//')
#_ip6=$(printf "$_date$_machineID" | sha1sum | cut -c 31- | sed 's/\(....\)/\1:/g' | sed 's/:$//')
#ip6=$(echo "$_ip6" | sed 's/\(....\)/\1:/g' | sed 's/:$//')

# 40df:be0f:1692::1/64

sudo bash -c "cat > /etc/wireguard/$wg_profile_name.conf <<EOL
[Interface]
PrivateKey = ${_prv_key}
Address = ${_ip4}/24, ${_ip6}::1/64
ListenPort = 51820
SaveConfig = true
PostUp = ufw route allow in on wg0 out on eth0
PostUp = iptables -t nat -I POSTROUTING -o eth0 -j MASQUERADE
PostUp = ip6tables -t nat -I POSTROUTING -o eth0 -j MASQUERADE
PreDown = ufw route delete allow in on wg0 out on eth0
PreDown = iptables -t nat -D POSTROUTING -o eth0 -j MASQUERADE
PreDown = ip6tables -t nat -D POSTROUTING -o eth0 -j MASQUERADE
EOL"

sudo bash -c "cat >> /etc/sysctl.conf <<EOL
net.ipv4.ip_forward=1
net.ipv6.conf.all.forwarding=1
EOL"

sudo sysctl -p
sudo ufw allow 51820/udp

sudo systemctl start wg-quick@$wg_profile_name.service

######
[Interface]
PrivateKey = ##
Address = 10.0.0.2/24
Address = fd0d:86fa:c3bc::2/64
PostUp = ip rule add table 200 from 203.0.113.5
PostUp = ip route add table 200 default via 203.0.113.1
PreDown = ip rule delete table 200 from 203.0.113.5
PreDown = ip route delete table 200 default via 203.0.113.1

[Peer]
PublicKey = U9uE2kb/nrrzsEU58GD3pKFU3TLYDMCbetIsnV8eeFE=
AllowedIPs = 10.0.0.0/24, fd0d:86fa:c3bc::/64
Endpoint = 203.0.113.1:51820