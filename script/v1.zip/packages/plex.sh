#!/bin/bash

ROOT_FOLDER="/nas/container/plex"

lower() { echo "$1" | awk '{print tolower($0)}'; }

echo "Plex Requires Port 1900 for DLNA."
read -p 'MiniDLNA will be disabled. Proceed ? (y/n) ' resp; if [ "$(lower $opt)" = "y" ]; then
sudo systemctl stop minidlna
sudo systemctl disable minidlna
else exit 1; fi

sudo docker pull plexinc/pms-docker

echo "Plex Claim Token  ( https://www.plex.tv/claim )"
read -p '  Token: ' token

sudo mkdir -p $ROOT_FOLDER/{database,transcode,media}; sudo chmod 777 -R $ROOT_FOLDER
sudo docker run \
  -d \
  --name plex \
  -p 32400:32400/tcp \
  -p 3005:3005/tcp \
  -p 8324:8324/tcp \
  -p 32469:32469/tcp \
  -p 1900:1900/udp \
  -p 32410:32410/udp \
  -p 32412:32412/udp \
  -p 32413:32413/udp \
  -p 32414:32414/udp \
  -e TZ="Europe/Prague" \
  -e PLEX_CLAIM="$token" \
  -v $ROOT_FOLDER/database:/config \
  -v $ROOT_FOLDER/transcode:/transcode \
  -v $ROOT_FOLDER/media:/data \
  plexinc/pms-docker