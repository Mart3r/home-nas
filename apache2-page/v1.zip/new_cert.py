from OpenSSL import crypto,SSL
from os import path

out_dir = "/var/www/html"

key = crypto.PKey()
key.generate_key(crypto.TYPE_RSA,2048)
cert = crypto.X509()
cert.get_subject().C = "CZ"
cert.get_subject().emailAddress = "M.Zerzan@outlook.cz"
cert.get_subject().L = "Pardubice"
cert.get_subject().CN = "Generated Certificate"
cert.get_subject().ST = "Czech Republic"
cert.set_serial_number(1000)
cert.gmtime_adj_notBefore(0)
cert.gmtime_adj_notAfter(365*24*60*60)
cert.set_issuer(cert.get_subject())
cert.set_pubkey(key)
cert.sign(key, 'sha256')

CERT_FILE=path.join(out_dir,"new_cert.crt")
KEY_FILE =path.join(out_dir,"new_priv_key.key")

open(CERT_FILE, "wb").write(crypto.dump_certificate(crypto.FILETYPE_PEM, cert))
open(KEY_FILE, "wb").write(crypto.dump_privatekey(crypto.FILETYPE_PEM, key))
