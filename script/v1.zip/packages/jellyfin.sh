
ROOT_FOLDER="/nas/container/jellyfin"


sudo mkdir -p "$ROOT_FOLDER/{config,media,cache}"
docker run -d --name jellyfin \
    -p 8096:8096 \
    -p 8920:8920 \
    -p 1900:1900 \
    -p 7359:7359 \
    -v $ROOT_FOLDER/config:/config \
    -v $ROOT_FOLDER/media:/media \
    -v $ROOT_FOLDER/cache:/cache \
    jellyfin/jellyfin

ufw allow 8096