
unix_socket="n"
new_root_passwd="Vltava184"
remove_anonymous="y"
disable_remote_root="y"
remove_test_db="y"
reload_privilage="y"

echo "
$unix_socket
$new_root_passwd
$new_root_passwd
$remove_anonymous
$disable_remote_root
$remove_test_db
$reload_privilage
" | sudo mysql_secure_installation