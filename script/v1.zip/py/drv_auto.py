from collections import namedtuple
import subprocess,yaml,os.path,datetime

drv_yaml = "/server/drives.yml"
log_file = "/server/auto_drive.log"


def log(logLevel,logMessage):
    date=datetime.datetime.now().strftime("%d.%m.%Y %H:%M:%S")
    data = f"[{logLevel:8} -- {date}] {logMessage}"
    print(data)
    open(log_file,"a").write(data)
    
std = namedtuple("std",['stdin','stdout','stderr','return_code'],defaults=["","","",1])
def call(cmd:str) -> std: 
    'Returns Named Tuple (stdin,stdout,stderr,return_code)'
    resp=subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=True)
    return std(cmd, resp.stdout.decode().strip(), resp.stderr.decode().strip(), resp.returncode)
def findMount(uuid)->str: return call(f"findmnt -n -o TARGET -S UUID={uuid}").stdout
def uuidExist(uuid)->bool: return os.path.exists(f"/dev/disk/by-uuid/{uuid}")
def mount(uuid,path)->std: return call(f"sudo mount UUID={uuid} {path}")
def unmount(uuid)->std: return call(f"sudo umount UUID={uuid}")
    

if os.path.exists(drv_yaml): drv_conf:dict = yaml.safe_load(open(drv_yaml))
else: 
    log("CRITICAL",f'Config File Not Found "{drv_yaml}"')
    exit(1)

for label, data in drv_conf.items():
    enabled, uuid, path, script = data.get("ENABLE",False), data.get("UUID",None), data.get("PATH",None), data.get("SCRIPT",None)
    if enabled:
        if (uuid is not None) or (path is not None):
            if uuidExist(uuid):
                if os.path.exists(path)==False:
                    log("WARN",f'Mount Directory "{path}" for "{label}" not found')
                    continue
                current_mount = findMount(uuid)
                if current_mount != path:
                    if current_mount.strip() != "":
                        resp = unmount(uuid)
                        if resp.return_code == 0: log("INFO",f'Drive "{label}" Unmounted. UUID: "{uuid}"')  
                        else: log("WARN",f'Label: "{label}"  UUID: {uuid}  Unmount Error: {resp.stderr}')
                    resp = mount(uuid,path)
                    if resp.return_code == 0: log("INFO",f'Drive "{label}" Mounted to "{path}". UUID: "{uuid}"')  
                    else: log("WARN",f'Label: "{label}"  UUID: {uuid}  Mount Error: {resp.stderr}')
                    if script != None: 
                        resp = call(f"sudo sh {script}")
                        log("INFO",f'Trying to run "{script}" from drive "{label}" with UUID: "{uuid}"')
                        if resp.return_code==0: print(resp.stdout)
                        else: print(f"[{resp.return_code}]  {resp.stderr}")