install_url="https://download.nextcloud.com/server/releases/latest.zip"

DB_NAME="nextcloud"
DB_USER="nextcloud"
DB_PASS="Vltava184"

SERVER_NAME="nextcloud"
DOC_ROOT="/var/www/nextcloud"
PORT=8080

sudo apt update -y && sudo apt upgrade -y
sudo apt install mariadb-server unzip -y
sudo apt install php8.1 php8.1-apcu php8.1-bcmath php8.1-cli php8.1-common php8.1-curl php8.1-gd php8.1-gmp php8.1-imagick php8.1-intl php8.1-mbstring php8.1-mysql php8.1-zip php8.1-xml -y
#  MariaDB
echo "
CREATE DATABASE ${DB_NAME};
GRANT ALL PRIVILEGES ON ${DB_NAME}.* TO '${DB_USER}'@'localhost' IDENTIFIED BY '${DB_PASS}';
FLUSH PRIVILEGES;
" | sudo mariadb
#  Apache & PHP Modules/Mods
sudo phpenmod bcmath gmp imagick intl
sudo a2enmod dir env headers mime rewrite ssl
#  Nextcloud Download & Move
wget -O /tmp/latest.zip $install_url
unzip /tmp/latest.zip
sudo chown -R www-data:www-data nextcloud
sudo mkdir $DOC_ROOT
sudo mv nextcloud/* $DOC_ROOT
#  New Apache2 File
sudo bash -c "cat > /etc/apache2/sites-available/nextcloud.conf <<EOL
<VirtualHost *:${PORT}>
    DocumentRoot \"${DOC_ROOT}\"
    ServerName ${SERVER_NAME}
    <Directory \"${DOC_ROOT}/\">
        Options MultiViews FollowSymlinks
        AllowOverride All
        Order allow,deny
        Allow from all
    </Directory>
    TransferLog /var/log/apache2/nextcloud_access.log
    ErrorLog /var/log/apache2/nextcloud_error.log
</VirtualHost>
EOL"
#  Add Port to Apache2 Ports
echo "Listen 8080" >> /etc/apache2/ports.conf
#  PHP Config Edit
sudo sed -i 's/^;?\s*memory_limit\s*=.*/memory_limit = 512M/' /etc/php/8.1/apache2/php.ini
sudo sed -i 's/^;?\s*upload_max_filesize\s*=.*/upload_max_filesize = 200M/' /etc/php/8.1/apache2/php.ini
sudo sed -i 's/^;?\s*max_execution_time\s*=.*/max_execution_time = 360/' /etc/php/8.1/apache2/php.ini
sudo sed -i 's/^;?\s*post_max_size\s*=.*/post_max_size = 200M/' /etc/php/8.1/apache2/php.ini
sudo sed -i 's/^;?\s*date.timezone\s*=.*/date.timezone = Europe\/Prague/' /etc/php/8.1/apache2/php.ini
sudo sed -i 's/^;?\s*opcache.enable\s*=.*/opcache.enable=1/' /etc/php/8.1/apache2/php.ini
sudo sed -i 's/^;?\s*opcache.interned_strings_buffer\s*=.*/opcache.interned_strings_buffer=8/' /etc/php/8.1/apache2/php.ini
sudo sed -i 's/^;?\s*opcache.max_accelerated_files\s*=.*/opcache.max_accelerated_files=10000/' /etc/php/8.1/apache2/php.ini
sudo sed -i 's/^;?\s*opcache.memory_consumption\s*=.*/opcache.memory_consumption=128/' /etc/php/8.1/apache2/php.ini
sudo sed -i 's/^;?\s*opcache.save_comments\s*=.*/opcache.save_comments=1/' /etc/php/8.1/apache2/php.ini
sudo sed -i 's/^;?\s*opcache.revalidate_freq\s*=.*/opcache.revalidate_freq=1/' /etc/php/8.1/apache2/php.ini
#  Enable Site & Restart Apache2
sudo a2dissite 000-default.conf
sudo a2ensite nextcloud; sudo systemctl restart apache2
#  Correct Perms
sudo chown -R www-data:www-data $DOC_ROOT
sudo chmod 660 /var/www/nextcloud/config/config.php
sudo chown root:www-data /var/www/nextcloud/config/config.php
#  Remove Image Magick Error
sudo apt install libmagickcore-6.q16-6-extra -y

#  Enable Memory Caching  (WIP  This Command Causes PHP Error Because Key is added at wrong place)
#sudo echo "'memcache.local' => '\\OC\\Memcache\\APCu'," >> /var/www/nextcloud/config/config.php
#  Set Phone Region  (WIP  This Command Causes PHP Error Because Key is added at wrong place)
#sudo echo "'default_phone_region' => 'CZ'," >> /var/www/nextcloud/config/config.php