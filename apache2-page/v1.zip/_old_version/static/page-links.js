var webmin = 10000
var portainer = 9000
var dlna = 8200
var nextcloud = 8080
var cockpit = 9090

window.onload = function() {
    var host = window.location.hostname;

    setPageLink("downloads-link","download.php")
    setPageLink("indexV2-link","indexV2.php")

    setLink('webmin-link', webmin);
    setLink('portainer-link', portainer);
    setLink('dlna-link', dlna);
    setLink('nextcloud-link', nextcloud);
    setLink('cockpit-link',cockpit);

    setAutoLink('webmin-autolink', webmin);
    setAutoLink('portainer-autolink', portainer);
    setAutoLink('dlna-autolink', dlna);
    setAutoLink('nextcloud-autolink', nextcloud);
    setAutoLink('cockpit-autolink',cockpit);

    function setLink(elementId, port) {
        let el = document.getElementById(elementId);
        if (el) el.href = `http://${host}:${port}/`;
    }
    function setAutoLink(elementId, port) {
        let el = document.getElementById(elementId);
        if (el) window.location.href = `http://${host}:${port}/`;
    }
    function setPageLink(elementId, pagePath) {
        let el = document.getElementById(elementId);
        if (el) el.href = `http://${host}/${pagePath}`;
    }
}
