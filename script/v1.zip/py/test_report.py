from collections import namedtuple
import subprocess,socket,os,platform

class ansi:
    BLACK = "\033[30m"
    RED = "\033[31m"
    GREEN = "\033[32m"
    YELLOW = "\033[33m"
    BLUE = "\033[34m"
    MAGENTA = "\033[35m"
    CYAN = "\033[36m"
    WHITE = "\033[37m"
    RESET = "\033[0m"

std = namedtuple("std",['stdin','stdout','stderr','return_code'],defaults=["","","",1])
def call(cmd:str) -> std: 
    'Returns Named Tuple (stdin,stdout,stderr,return_code)'
    resp=subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=True)
    return std(cmd, resp.stdout.decode().strip(), resp.stderr.decode().strip(), resp.returncode)
def center(text: str, max_length: int) -> str:
    total_padding = max_length - len(text)
    return ' ' * (total_padding // 2) + text + ' ' * (total_padding - (total_padding // 2))
def ping(host, count=4):
    cmd = ["ping", "-n", str(count), host] if platform.system().lower() == "windows" else ["ping", "-c", str(count), host]
    with open(os.devnull, 'w') as devnull: 
        if subprocess.run(cmd, stdout=devnull, stderr=devnull).returncode == 0: return True
        else: return False

def get_drive_info():
    # Using lsblk to get information about drives in JSON format
    result = call("sudo lsblk -o MOUNTPOINT,LABEL,UUID -J").stdout
    data, drives = eval(result), []
    for device in data["blockdevices"]:
        if 'children' in device:
            for child in device['children']:
                drives.append({'MOUNTPOINT': child['mountpoint'] if child['mountpoint'] else "N/A", 'LABEL': child['label'] if child['label'] else "N/A", 'UUID': child['uuid'] if child['uuid'] else "N/A"})
        else: drives.append({'MOUNTPOINT': device['mountpoint'] if device['mountpoint'] else "N/A", 'LABEL': device['label'] if device['label'] else "N/A", 'UUID': device['uuid'] if device['uuid'] else "N/A" })
    return drives

PingServer = "google.com"

hostname=socket.gethostname()
address=socket.gethostbyname(hostname)
net = ping(PingServer)

print(f'Ping: {"OK" if net else "FAILED"} ({PingServer})')
print(f'Hostname: "{hostname}"')
print(f'Address: {address}')

print('Drives:')
for drv in get_drive_info(): print(f'   {drv["MOUNTPOINT"]} || {drv["LABEL"]}  UUID: {drv["UUID"]}')