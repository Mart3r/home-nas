# PhotoPrism Port  2342
ADMIN_PASSWORD="insecure"
NAS_FOLDER="/nas/container/photoprism"
PUBLIC=true


if $PUBLIC; then public="true"; else public="false"; fi;

sudo apt update
sudo mkdir -p $NAS_FOLDER

docker run -d \
  --name photoprism \
  --security-opt seccomp=unconfined \
  --security-opt apparmor=unconfined \
  -p 2342:2342 \
  -e PHOTOPRISM_UPLOAD_NSFW="true" \
  -e PHOTOPRISM_ADMIN_PASSWORD="$ADMIN_PASSWORD" \
  -e PHOTOPRISM_PUBLIC="$public" \
  -v /photoprism/storage \
  -v $NAS_FOLDER:/photoprism/originals \
  photoprism/photoprism

ufw allow 2342
echo "Default Login  Username: admin   Password: insecure"