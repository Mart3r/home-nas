<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $output = shell_exec('python3 /var/www/html/new_cert.py');
    echo $output;
}
?>

<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="static/styles.css">
    <title>Downloads</title>
    <script src="static/page-links.js"></script>
</head>
<body style="background-color:rgb(25,25,25); color: rgb(238, 238, 238)">
    <h1>Available Downloads</h1>
    <form action="cert.php" method="post">
    <input type="submit" value="Create New Certificate">
    <li><a href="new_cert.crt" download><button class="button-28" role="button" type="button" style="width: 150px;">Download Certificate</button></a></li>
    <li><a href="new_priv_key.key" download><button class="button-28" role="button" type="button" style="width: 150px;">Download Private Key</button></a></li>
</form>
</body>
</html>
