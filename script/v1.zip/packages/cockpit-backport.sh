REPO_LINE="deb http://deb.debian.org/debian $(lsb_release -cs)-backports main"
REPO_FILE="/etc/apt/sources.list.d/backports.list"
if ! grep -q "$REPO_LINE" "$REPO_FILE"; then echo "$REPO_LINE" | sudo tee -a "$REPO_FILE" && echo "Repository added!"; else echo "Repository already exists!"; fi

apt update
sudo apt install -t $(lsb_release -cs)-backports cockpit