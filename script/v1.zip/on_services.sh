#!/bin/sh

atBootScriptPath=$1
atShutdownScriptPath=$2

#atBootScriptPath="/usr/local/bin/on-boot.sh"
#atShutdownScriptPath="/usr/local/bin/on-shutdown.sh"

atBootServiceName="on-boot"
atShutdownServiceName="on-shutdown"

# Boot Service
if [ -f $atBootScriptPath ]; then
    echo ""
else
    sudo bash -c "cat > $atBootScriptPath <<EOL
    #!/bin/bash
    EOL"
fi
sudo chmod +x $atBootScriptPath
sudo bash -c "cat > /etc/systemd/system/$atBootServiceName.service <<EOL
[Unit]
Description=Run script after boot
After=network.target

[Service]
Type=simple
ExecStart=${atBootScriptPath}

[Install]
WantedBy=multi-user.target
EOL"
sudo systemctl enable $atBootServiceName.service
sudo systemctl start $atBootServiceName.service

# Shutdown Service
if [ -f $atShutdownScriptPath ]; then
    echo ""
else
    sudo bash -c "cat > $atShutdownScriptPath <<EOL
    #!/bin/bash
    EOL"
fi
sudo chmod +x $atShutdownScriptPath
sudo bash -c "cat > /etc/systemd/system/$atShutdownServiceName.service <<EOL
[Unit]
Description=Run script before shutdown
DefaultDependencies=no
Before=shutdown.target reboot.target halt.target

[Service]
Type=oneshot
ExecStart=${atShutdownScriptPath}
RemainAfterExit=true

[Install]
WantedBy=halt.target reboot.target shutdown.target
EOL"
sudo systemctl enable $atShutdownServiceName.service
sudo systemctl start $atShutdownServiceName.service
